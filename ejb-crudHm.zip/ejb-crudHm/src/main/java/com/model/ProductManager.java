package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import com.entity.Product;

public class ProductManager implements ProductRemote {

	@Override
	public String saveData(Product P) throws Exception {
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/klu","root","Areef1ar@");
		  PreparedStatement ps=con.prepareStatement("insert into product values(?,?,?)");
		  ps.setInt(1, P.getPid());
		  ps.setString(2, P.getPname());
		  ps.setInt(3, P.getPcost());
		  ps.execute();
		  con.close();
		  return "Record saved successfully";

	}

	@Override
	public List<Product> getData() throws Exception {
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/klu","root","Areef1ar@");
		  PreparedStatement ps=con.prepareStatement("select * from product ");
		  ResultSet rs=ps.executeQuery();
		  List<Product> L=new ArrayList<Product>();
		  while(rs.next())
		  {
		   Product e=new Product();
		   e.setPid(rs.getInt(1));
		   e.setPname(rs.getString(2));
		   e.setPcost(rs.getInt(3));
		   L.add(e);
		  }
		  con.close();
		  return L;
		
	}

	@Override
	public String updateData(Product P) throws Exception {
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/klu","root","Areef1ar@");
		  PreparedStatement ps=con.prepareStatement("update product set pname=?,pcost=? where pid=?");
		  ps.setString(1, P.getPname());
		  ps.setInt(2, P.getPcost());
		  ps.setInt(3,P.getPid());
		  ps.execute();
		  con.close();
		  return "Record updated Sucessfully";
	}

	@Override
	public String deleteData(Product P) throws Exception {
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/klu","root","Areef1ar@");
		  PreparedStatement ps=con.prepareStatement("delete from product where pid=?");
		  ps.setInt(1, P.getPid());
		  ps.execute();
		  con.close();
		  return "Record deleted successfully";
		
	}

	

}
