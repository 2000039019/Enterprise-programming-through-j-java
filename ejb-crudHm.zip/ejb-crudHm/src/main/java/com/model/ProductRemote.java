package com.model;

import java.util.List;

import com.entity.Product;



public interface ProductRemote {
	public  String saveData(Product P)throws Exception;
	public List<Product> getData() throws Exception;
	public  String updateData(Product P) throws Exception;
	public String deleteData(Product P) throws Exception;

}
