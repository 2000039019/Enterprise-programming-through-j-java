package com.entity;

import java.io.Serializable;

public class Product implements Serializable
{
	 private static final long serialVersionUID = 1L;

	int pid;
	String pname;
	int pcost;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPcost() {
		return pcost;
	}
	public void setPcost(int pcost) {
		this.pcost = pcost;
	}

	
}
