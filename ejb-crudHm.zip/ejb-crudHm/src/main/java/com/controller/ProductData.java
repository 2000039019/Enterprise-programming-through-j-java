package com.controller;

import java.util.List;


import javax.faces.bean.ManagedBean;

import com.entity.Product;
import com.model.ProductRemote;



@ManagedBean(name="pd",eager=true)
public class ProductData
{
int pid;
String pname;
int pcost;
String response;
List<Product> list;
ProductRemote pr;
public void save()
{
 try
 {
	 Product P=new Product();
     P.setPid(pid);
     P.setPname(pname);
      P.setPcost(pcost);
     response=pr.saveData(P);
 }
 catch(Exception e)
 {
  response=e.getMessage();
 }
}
public void update()
{
 try
 {
	 Product P=new Product();
     P.setPid(pid);
     P.setPname(pname);
      P.setPcost(pcost);
     response=pr.saveData(P);
 }
 catch(Exception e)
 {
  response=e.getMessage();
 }
}
public void delete()
{
 try
 {
	 Product P=new Product();
     P.setPid(pid);
     P.setPname(pname);
      P.setPcost(pcost);
     response=pr.saveData(P);
 }
 catch(Exception e)
 {
  response=e.getMessage();
 }
}


public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public int getPcost() {
	return pcost;
}
public void setPcost(int pcost) {
	this.pcost = pcost;
}
public String getResponse() {
	return response;
}
public void setResponse(String response) {
	this.response = response;
}
public List<Product> getList()
{
 try
 {
  list=pr.getData();
  
 }
 catch(Exception e)
 {
  response=e.getMessage();
 }
 return list;
}
public void setList(List<Product> list) {
 this.list = list;
}

}