package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EmployeeManager {
	String url="jdbc:mysql://localhost:3306/klu_emp";
	String username="root";
	String password="Areef1ar@";
	Connection con=null;
	PreparedStatement ps=null;
	public List<Employee> getDetails()throws Exception
	{
	 con=DriverManager.getConnection(url,username,password);
	 ps=con.prepareStatement("select * from employee");
	 ResultSet rs=ps.executeQuery();
	 List<Employee> L=new ArrayList<Employee>();
	 while(rs.next())
	 {
		 Employee b=new Employee();
		 b.setEmpid(rs.getInt(1));
		 b.setEmpname(rs.getString(2));
		 b.setEmpadd(rs.getString(3));
		 b.setEmpsal(rs.getDouble(4));
		 L.add(b);
	 }
	 return L;
	}

}
