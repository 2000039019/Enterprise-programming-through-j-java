package com.klu.jdbcdemo;

import java.sql.*;


public class App 
{
    

	public static void main( String[] args )throws Exception
    {
    	 String url = "jdbc:mysql://localhost:3306/kl_u";
    	 String username="root";
    	 String password="Areef1ar@";
    	 Connection con=DriverManager.getConnection(url,username,password);
    	 Statement stmt=con.createStatement();
    	 String s1="select * from student";
    	 ResultSet res=stmt.executeQuery(s1);
    	 while(res.next())
    	 {
    		 System.out.print(res.getInt(1));
    		 System.out.println(res.getString(2));


    		 
    	 }
    	 con.close();
    	 
    	 
    	
    }
}
