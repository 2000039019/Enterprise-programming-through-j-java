package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class HospitalManager {
	String url="jdbc:mysql://localhost:3306/kl_u";
	String username="root";
	String password="Areef1ar@";
	Connection con=null;
	PreparedStatement ps=null;
	public List<Hospital> readData()throws Exception
	{
	 con=DriverManager.getConnection(url,username,password);
	 ps=con.prepareStatement("select * from hospital");
	 ResultSet rs=ps.executeQuery();
	 List<Hospital> L=new ArrayList<Hospital>();
	 while(rs.next())
	 {
		 Hospital b=new Hospital();
		 b.setPid(rs.getInt(1));
		 b.setPname(rs.getString(2));
		 b.setPdi(rs.getString(3));
		 b.setPadd(rs.getString(4));

		 L.add(b);
	 }
	 con.close();
	 return L;
	}

}
