package com.model;

public class Hospital {
	int pid;
	String pname;
	String pdi;
	String padd;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPdi() {
		return pdi;
	}
	public void setPdi(String pdi) {
		this.pdi = pdi;
	}
	public String getPadd() {
		return padd;
	}
	public void setPadd(String padd) {
		this.padd = padd;
	}
	

}
