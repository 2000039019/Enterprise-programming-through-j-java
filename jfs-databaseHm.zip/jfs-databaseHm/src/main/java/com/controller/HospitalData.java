package com.controller;

import java.util.List;

import javax.faces.bean.ManagedBean;

import com.model.Hospital;
import com.model.HospitalManager;


@ManagedBean(name="studentdata",eager=true)

public class HospitalData {
	List<Hospital> list;

	public List<Hospital> getList() 
	{
		try
		{
			HospitalManager sm=new HospitalManager();
			list=sm.readData();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return list;
	}

	public void setList(List<Hospital> list)
	{
		this.list = list;
	}

}
