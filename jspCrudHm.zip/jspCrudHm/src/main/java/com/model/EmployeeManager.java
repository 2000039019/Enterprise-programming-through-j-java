package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EmployeeManager {
	
	String url="jdbc:mysql://localhost:3306/klu_emp";
	String username="root";
	String password="Areef1ar@";
	Connection con=null;
	PreparedStatement ps=null;
	public String saveData(Employee S)throws Exception
	{
		con=DriverManager.getConnection(url,username,password);
		ps=con.prepareStatement("insert into employee values(?,?,?,?)");
		
		ps.setInt(1, S.getEmpid());
		ps.setString(2,S.getEmpname());
		ps.setString(3, S.getEmpaddress());
		ps.setDouble(4, S.getEmpsal());
		ps.execute();
		con.close();
		return "data inserted successfully";
	}
	public List<Employee> readData()
	{
		List<Employee> L =new ArrayList<Employee>();
		try
		{
			con=DriverManager.getConnection(url,username,password);
			ps=con.prepareStatement("select * from employee");
			ResultSet rs=ps.executeQuery();
			while(rs.next())			
			
			{
				Employee s=new Employee();
				s.setEmpid(rs.getInt(1));
				s.setEmpname(rs.getString(2));
				s.setEmpaddress(rs.getString(3));
				s.setEmpsal(rs.getDouble(4));
				L.add(s);
			}
			con.close();
			
		}
		catch(Exception e)
		{
			
			
		}
		return L;
		

}
}
