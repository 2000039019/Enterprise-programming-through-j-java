package com.contoller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Employee;
import com.model.EmployeeManager;



public class AddData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		try
		{
			Employee s=new Employee();
			EmployeeManager sm=new EmployeeManager();
			int Empid=Integer.parseInt(request.getParameter("empid"));
			String Empname=request.getParameter("empname");
			String Empaddress=request.getParameter("empaddress");

			Double Empsal=Double.parseDouble(request.getParameter("empsalary"));
			s.setEmpid(Empid);
			s.setEmpname(Empname);
			s.setEmpaddress(Empaddress);
			s.setEmpsal(Empsal);

		
			String ack=sm.saveData(s);
			pw.print(ack);
			
			
		}
		catch(Exception e)
		{
			pw.print(e.getMessage());
			
		}
				
		RequestDispatcher rd=request.getRequestDispatcher("addnew.jsp");
		rd.include(request,response);
	}
		
		
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
