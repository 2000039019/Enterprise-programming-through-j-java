package com.klu;

import javax.faces.bean.ManagedBean;
import javax.validation.constraints.Size;

@ManagedBean(name="user",eager=true)
public class UserData {
	@Size(min=1)
	String name;
	@Size(min=10,max=10)
	String empid;
	@Size(min=6,max=6)
	String empsal;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getEmpsal() {
		return empsal;
	}
	public void setEmpsal(String empsal) {
		this.empsal = empsal;
	}
	
	

}
